#include "WinAPI.22.S4.L.CPP.PwSG.h"



int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Place code here.

    // Initialize global strings
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINAPI22S4LCPPPWSG, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Perform application initialization:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WINAPI22S4LCPPPWSG));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int)msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex, child;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDC_WINAPI22S4LCPPPWSG));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_WINAPI22S4LCPPPWSG);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    child.cbSize = sizeof(WNDCLASSEX);

    child.style = 0;
    child.lpfnWndProc = WndProcChild;
    child.cbClsExtra = 0;
    child.cbWndExtra = 0;
    child.hInstance = hInstance;
    child.hIcon = NULL;
    child.hCursor = LoadCursor(NULL, IDC_ARROW);
    child.hbrBackground = CreateSolidBrush(RGB(200, 200, 200));
    child.lpszMenuName = NULL;
    child.lpszClassName = _T("ChildWindow");
    child.hIconSm = NULL;

    RegisterClassExW(&child);

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance; // Store instance handle in our global variable

    srand(time(nullptr));

    iBoxesHeight = Random(iBoxesMinHeight, iBoxesMaxHeight);//iBoxesMinHeight + (rand() % (iBoxesMaxHeight - iBoxesMinHeight));
    iBoxesWidth = Random(iBoxesMinWidth, iBoxesMaxWidth);//iBoxesMinWidth + (rand() % (iBoxesMaxWidth - iBoxesMinWidth));

    const int iDistBetweenBoxes = iActualDistBetweenBoxes - 2;		// Don't ask :^)

    iWindowHeight = CalculateWindowHeight(iBoxesHeight, iBoxSize, iDistBetweenBoxes, iWindowTitleHeight);//iBoxesHeight * (iBoxSize + iDistBetweenBoxes) + 59 + iWindowTitleHeight + 2 * iDistBetweenBoxes;
    iWindowWidth = CalculateWindowWidth(iBoxesWidth, iBoxSize, iDistBetweenBoxes);//iBoxesWidth * (iBoxSize + iDistBetweenBoxes) + 16 + 2 * iDistBetweenBoxes;
    
    //int xPos = (GetSystemMetrics(SM_CXSCREEN) + 2 * iDistBetweenBoxes - iWindowWidth) / 2;
    //int yPos = (GetSystemMetrics(SM_CYSCREEN) + 2 * iDistBetweenBoxes - iWindowHeight) / 2;

    POINT Pos = GetCenterOfScreenPosition(iWindowWidth, iWindowHeight, iDistBetweenBoxes);
    

    HWND hWnd = CreateWindowW(
        szWindowClass,
        szTitle,
        /*WS_OVERLAPPED | */WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        Pos.x, Pos.y,
        iWindowWidth, iWindowHeight,
        nullptr,
        nullptr,
        hInstance,
        nullptr);

    if (!hWnd)
    {
        return FALSE;
    }

    g_hWnd = hWnd;

    WCHAR str[MAX_LOADSTRING];
    _stprintf_s(str, MAX_LOADSTRING, _T("Minesweeper | Time: %.01f"), current_time);
    SetWindowTextW(hWnd, str);

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    HWND** hWndChild = nullptr;
    CreateNewChildren(hWndChild, hWnd, iBoxesWidth, iBoxesHeight, iBoxSize, iDistBetweenBoxes, iWindowTitleHeight);

    g_hWndChild = hWndChild;

    return TRUE;
}

INT Random(INT min, INT max)
{
    return min + (rand() % (max - min));
}

INT	CalculateWindowHeight(INT boxes_height, INT box_size, INT btwboxes_dist, INT title = iWindowTitleHeight)
{
    return boxes_height * (box_size + btwboxes_dist) + 59 + title + 2 * btwboxes_dist;
}

INT	CalculateWindowWidth(INT boxes_width, INT box_size, INT btwboxes_dist)
{
    return boxes_width * (box_size + btwboxes_dist) + 16 + 2 * btwboxes_dist;
}

BOOL DeleteChildren(HWND** Children)
{
    for (int i = 0; i < iBoxesHeight; i++)
    {
        for (int j = 0; j < iBoxesWidth; j++)
        {
            //SetParent(Children[i][j], nullptr);

            if (!DestroyWindow(Children[i][j])) return FALSE;
        }
        delete Children[i];
    }
    delete Children;

    return TRUE;
}

BOOL CreateNewChildren(HWND** childptr, HWND parentptr, INT width, INT height, INT boxsize, INT boxdist, INT title)
{
    childptr = new HWND* [height];
    for (int i = 0; i < height; i++)
    {
        childptr[i] = new HWND[width];
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            childptr[i][j] = CreateWindowW(
                _T("ChildWindow"),
                nullptr,
                WS_BORDER | WS_CHILD | BS_DEFPUSHBUTTON,
                (j + 1) * boxdist + j * (boxsize),
                (i + 1) * boxdist + i * (boxsize)+title,
                boxsize,
                boxsize,
                parentptr,
                nullptr,
                (HINSTANCE)GetWindowLongPtrW(parentptr, GWLP_HINSTANCE),
                nullptr);

            if (!childptr[i][j]) return FALSE;

            SetWindowLong(childptr[i][j], GWL_STYLE, 0);
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            ShowWindow(childptr[i][j], 1);
            UpdateWindow(childptr[i][j]);
        }
    }

    //g_hWndChild = childptr;

    return FALSE;
}

POINT GetCenterOfScreenPosition(INT width, INT height, INT boxdistance)
{
    //int xPos = (GetSystemMetrics(SM_CXSCREEN) + 2 * iDistBetweenBoxes - iWindowWidth) / 2;
	//int yPos = (GetSystemMetrics(SM_CYSCREEN) + 2 * iDistBetweenBoxes - iWindowHeight) / 2;

    return POINT({ (GetSystemMetrics(SM_CXSCREEN) + 2 * boxdistance - width) / 2,
    (GetSystemMetrics(SM_CYSCREEN) + 2 * boxdistance - height) / 2 });
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;

    tagRECT lprRect;
    GetClientRect(hWnd, &lprRect);

    GetCursorPos(&currentMousePos);
    ScreenToClient(hWnd, &currentMousePos);


    switch (message)
    {
    case WM_LBUTTONDOWN:
    {

    }
    break;
    case WM_TIMER:
    {
        if (wParam == timerId && bTimerStarted)
        {
            current_time += time_step;

            WCHAR str[MAX_LOADSTRING];
            _stprintf_s(str, MAX_LOADSTRING, _T("Minesweeper | Time: %.01f"), current_time);

            SetWindowTextW(hWnd, str);
        }
    }
    break;
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        case IDM_GAME_NEW:
	        {
				if(g_hWndChild) DeleteChildren(g_hWndChild);

                iBoxesHeight = Random(iBoxesMinHeight, iBoxesMaxHeight);
                iBoxesWidth = Random(iBoxesMinWidth, iBoxesMaxWidth);

                const int iDistBetweenBoxes = iActualDistBetweenBoxes - 2;

                iWindowHeight = CalculateWindowHeight(iBoxesHeight, iBoxSize, iDistBetweenBoxes, iWindowTitleHeight);//iBoxesHeight * (iBoxSize + iDistBetweenBoxes) + 59 + iWindowTitleHeight + 2 * iDistBetweenBoxes;
                iWindowWidth = CalculateWindowWidth(iBoxesWidth, iBoxSize, iDistBetweenBoxes);//iBoxesWidth * (iBoxSize + iDistBetweenBoxes) + 16 + 2 * iDistBetweenBoxes;

                POINT newPos = GetCenterOfScreenPosition(iWindowWidth, iWindowHeight, iDistBetweenBoxes);

                MoveWindow(hWnd, newPos.x, newPos.y, iWindowWidth, iWindowHeight, TRUE);

                CreateNewChildren(g_hWndChild, hWnd, iBoxesWidth, iBoxesHeight, iBoxSize, iDistBetweenBoxes, iWindowTitleHeight);

                current_time = 0.0f;
                bTimerStarted = false; //TODO: BUG WITH WINDOW ACCESS


                //AdjustWindowRect(&lprRect, CS_HREDRAW | CS_VREDRAW, TRUE);
	        }
			break;
        case IDM_HELP_DEBUG:
	        {
				HMENU hMenu = GetMenu(hWnd);

                CheckMenuItem(hMenu, IDM_HELP_DEBUG, bDebug ? MF_UNCHECKED : MF_CHECKED);

                bDebug = !bDebug;
	        }
            break;
        case IDM_HELP_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_GAME_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_PAINT:
    {
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK WndProcChild(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    tagRECT lprRect;
    GetClientRect(hWnd, &lprRect);

    switch (message)
    {
    case WM_LBUTTONDOWN:
    {
        if (!bTimerStarted)
        {
            SetTimer(g_hWnd, timerId, (UINT)(time_step * 1000), NULL);
            bTimerStarted = !bTimerStarted;
        }
    }
	break;
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY:
        //PostQuitMessage(0);
        break;
    case WM_NCDESTROY:
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
