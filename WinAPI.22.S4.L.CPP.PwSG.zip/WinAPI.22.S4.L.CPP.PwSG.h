#pragma once

#include "resource.h"
#include "framework.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;                                // current instance
HINSTANCE hChildInst;
HWND g_hWnd;
HWND** g_hWndChild;
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name
RECT rClientRect{};

bool bTimerStarted = false;
bool bDebug = false;

INT iBoxesHeight{};
INT iBoxesWidth{};
INT iBoxesMinHeight = 10;
INT iBoxesMinWidth = 10;
INT iBoxesMaxHeight = 24;
INT iBoxesMaxWidth = 30;
INT iBoxSize = 25;
INT iActualDistBetweenBoxes = 1;

INT iWindowHeight{};
INT iWindowWidth{};
INT iWindowTitleHeight = 30;

INT_PTR timerId = 5;
FLOAT time_step = 0.01;
FLOAT current_time;

POINT currentMousePos{};

//----------------------------------------------------------------
// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
BOOL				DeleteChildren(HWND**);
BOOL				CreateNewChildren(HWND** childptr, HWND parentptr, INT width, INT height, INT boxsize, INT boxdist, INT title);
POINT				GetCenterOfScreenPosition(INT, INT, INT);
INT					CalculateWindowHeight(INT, INT, INT, INT);
INT					CalculateWindowWidth(INT, INT, INT);
INT					Random(INT, INT);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	WndProcChild(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);